print('hi')
input()